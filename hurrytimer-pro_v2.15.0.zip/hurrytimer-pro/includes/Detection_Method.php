<?php 
namespace Hurrytimer;

class Detection_Method{


  public function isEnabled(){
    
  }
}