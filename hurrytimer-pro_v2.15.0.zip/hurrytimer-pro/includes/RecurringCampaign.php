<?php 
namespace Hurrytimer;

class RecurringCampaign extends Campaign{
  public function __construct($id) {
      parent::__construct($id);
  }

  function getNextDeadline(){

  }


}