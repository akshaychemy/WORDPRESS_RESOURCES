<div class="hurryt-upgrade-banner">
    <img src="<?php echo HURRYT_URL . '/assets/images/upgrade_06a0.png' ?>" />
    <ul>
    <li><span class="dashicons dashicons-yes"></span>Restart Evergreen timer after a specific time<span class="hurryt-bg-purple-200 hurryt-rounded hurryt-px-1 hurryt-text-purple-800 hurryt-font-semibold">New</span></li>
    <li><span class="dashicons dashicons-yes"></span>Expire WooCommerce Coupon<span class="hurryt-bg-purple-200 hurryt-rounded hurryt-px-1 hurryt-text-purple-800 hurryt-font-semibold">New</span></li>
    <li><span class="dashicons dashicons-yes"></span>Recurring Countdown timer <span class="hurryt-bg-purple-200 hurryt-rounded hurryt-px-1 hurryt-text-purple-800 hurryt-font-semibold">New</span></li>
    <li><span class="dashicons dashicons-yes"></span>User Session detection for Evergreen timers<span class="hurryt-bg-purple-200 hurryt-rounded hurryt-px-1 hurryt-text-purple-800 hurryt-font-semibold">New</span></li>
    <li><span class="dashicons dashicons-yes"></span>Sticky Announcement Bar</li>
    <li><span class="dashicons dashicons-yes"></span>Advanced Design Customization</li>
        <li><span class="dashicons dashicons-yes"></span>Multiple Actions</li>
        <li><span class="dashicons dashicons-yes"></span>Custom CSS</li>
        <li><span class="dashicons dashicons-yes"></span>Inline Timer Display</li>
        <li><span class="dashicons dashicons-yes"></span>Priority Support</li>
    </ul>

    <a href="https://hurrytimer.com" class="button button-large hurryt-button">Get HurryTimer PRO</a>
</div>